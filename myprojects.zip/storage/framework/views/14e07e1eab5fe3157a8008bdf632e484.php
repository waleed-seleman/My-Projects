

<?php $__env->startSection('title', 'انشاء مشروع جديد'); ?>

<?php $__env->startSection('content'); ?>
    <div class = "row justify-content-center text-right">
        <div class = "col-10">
            <h3 class = "text-center pb-5 font-wight-bold">
                مشروع جديد
            </h3>
            <form action= "/projects" method="POST" dir="rtl">
                <?php echo $__env->make('projects.form', ["project" => new App\Models\Project()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>               
                <div class="form-group">
                    <button type = "submit" class = "btn btn-primary">انشاء</button>
                    <a href = "/projects" class = "btn btn-light">الغاء</a>
                </div>
            </form>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myprojects\resources\views/projects/create.blade.php ENDPATH**/ ?>