

<?php $__env->startSection('title', 'تعديل المشروع'); ?>

<?php $__env->startSection('content'); ?>
    <div class = "row justify-content-center text-right">
        <div class = "col-10">
            <h3 class = "text-center pb-5 font-wight-bold">
                تعديل المشروع
            </h3>
            <form action= "/projects/<?php echo e($project->id); ?>" method="POST" dir="rtl">
                <?php echo method_field("PATCH"); ?>
                <?php echo $__env->make('projects.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>               
                <div class="form-group">
                    <button type = "submit" class = "btn btn-primary">تعديل</button>
                    <a href = "/projects" class = "btn btn-light">الغاء</a>
                </div>
            </form>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myprojects\resources\views/projects/edit.blade.php ENDPATH**/ ?>