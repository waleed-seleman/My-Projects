

<?php $__env->startSection('content'); ?>
    <header class= "d-flex justify-content-between align-items-center my-5" dir = "rtl">
        <div class = "h6 text-dark">
            <a href= "/projects">المشاريع/ <?php echo e($project->title); ?></a>
        </div>
        <div>
            <a href = "/projects/<?php echo e($project->id); ?>/edit" class= "btn btn-primary px-4" role = "button">تعديل المشروع</a>
        </div>
    </header> 

    <section dir="rtl">
        <div class = "row">
            <div class = "col-lg-4">
                <div class = "card text-right">
                    <div class = "card-body">
                        <div class = "status">
                            <?php switch($project->status):
                                case (1): ?>
                                    <span class = "text-success">مكتمل</span>
                                    <?php break; ?>
                                <?php case (2): ?>
                                    <span class = "text-danger">ملغي</span>
                                    <?php break; ?>
                                <?php default: ?>
                                    <span class = "text-warning">قيد الانجاز</span>
                            <?php endswitch; ?>
                            <h5 class = "font-wight-bold card-title">
                                <a href = "/projects/<?php echo e($project->id); ?>"> <?php echo e($project->title); ?> </a>
                            </h5>
                            <div class = "card-text mt-4">
                                <?php echo e($project->description); ?>

                            </div>

                            <?php echo $__env->make('projects.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h5 class = "font-wight-bold card-title">
                            تغيير حالة المشروع
                        </h5>
                        <form action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PATCH"); ?>

                            <select name="status" class ="custom-select" onchange="this.form.submit()">
                                <option value="0" <?php echo e(($project->status == 0)? "selected" : ""); ?>>قيد الانجاز</option>
                                <option value="1" <?php echo e(($project->status == 1)? "selected" : ""); ?>>مكتمل</option>
                                <option value="2" <?php echo e(($project->status == 2)? "selected" : ""); ?>>ملغي</option>
                            </select>
                        </form>
                        
                    </div>
                </div>
            </div>
            <div class = "col-lg-8">
                <?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class = "card d-flex flex-row">
                        <div class = "<?php echo e($task->done ? "checked muted" : ""); ?>">
                            <?php echo e($task->body); ?>

                        </div>
                        <div class="mr-auto">
                            <form action="/projects/<?php echo e($project->id); ?>/tasks/<?php echo e($task->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("PATCH"); ?>
                                <input type="checkbox" name="done" <?php echo e($task->done ? "checked" : ""); ?> onchange="this.form.submit()">
                            </form>
                        </div>
                        <div class = "d-flex align-items-center mr-auto">
                            <form action="/projects/<?php echo e($task->project_id); ?>/tasks/<?php echo e($task->id); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="submit" class = "btn-delete" value="">
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class = "card">
                    <form action="/projects/<?php echo e($project->id); ?>/tasks" method="POST" class="d-flex">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="body" class="form-control p-2 ml-2" placeholder="اضف مهمة جديدة">
                        <button type="submit" class="btn btn-primary">اضافة</button>
                    </form>
                </div>
                

            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myprojects\resources\views/projects/show.blade.php ENDPATH**/ ?>